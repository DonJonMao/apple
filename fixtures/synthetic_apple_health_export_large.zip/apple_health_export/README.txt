Synthetic test fixture only. No personal data.
